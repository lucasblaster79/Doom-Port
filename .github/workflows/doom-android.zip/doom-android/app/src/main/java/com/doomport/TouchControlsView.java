package com.doomport;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import org.libsdl.app.SDLActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Controles tactiles superpuestos al juego. Convierte los toques en teclas de
 * Doom (las mismas del teclado original) y las inyecta en SDL.
 *
 *  Izquierda : cruz de movimiento (adelante/atras/girar, diagonales incluidas)
 *  Derecha   : FUEGO, USAR, cambiar arma, strafe
 *  Arriba    : ESC (menu), MAPA (TAB), OK (ENTER), Y / N para confirmar
 */
public class TouchControlsView extends View {

    private static class Btn {
        final String label;
        final int key;
        // posicion en dp: ax/ay = ancla (0=izq/arriba, 1=der/abajo, 0.5=centro), ox/oy = desplazamiento
        final float ax, ay, ox, oy, r;
        float cx, cy, rad;
        Btn(String label, int key, float ax, float ay, float ox, float oy, float r) {
            this.label = label; this.key = key;
            this.ax = ax; this.ay = ay; this.ox = ox; this.oy = oy; this.r = r;
        }
    }

    private final List<Btn> buttons = new ArrayList<Btn>();
    private final Set<Integer> down = new HashSet<Integer>();
    private final Set<Btn> pressedButtons = new HashSet<Btn>();

    // cruz de movimiento
    private float padCx, padCy, padR;
    private boolean padUp, padDown, padLeft, padRight;
    private float knobX, knobY;
    private boolean knobActive;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;

    public TouchControlsView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        setFocusable(false);

        // derecha-abajo
        buttons.add(new Btn("FUEGO", KeyEvent.KEYCODE_CTRL_LEFT, 1, 1, -100, -100, 56));
        buttons.add(new Btn("USAR",  KeyEvent.KEYCODE_SPACE,     1, 1, -205, -62, 38));
        // strafe (centro-abajo)
        buttons.add(new Btn("<S",    KeyEvent.KEYCODE_COMMA,     0.5f, 1, -42, -40, 30));
        buttons.add(new Btn("S>",    KeyEvent.KEYCODE_PERIOD,    0.5f, 1,  42, -40, 30));
        // armas (derecha-arriba)
        buttons.add(new Btn("<ARMA", KeyEvent.KEYCODE_LEFT_BRACKET,  1, 0, -135, 42, 28));
        buttons.add(new Btn("ARMA>", KeyEvent.KEYCODE_RIGHT_BRACKET, 1, 0,  -55, 42, 28));
        // menu (izquierda-arriba)
        buttons.add(new Btn("ESC",   KeyEvent.KEYCODE_ESCAPE, 0, 0,  45, 42, 26));
        buttons.add(new Btn("MAPA",  KeyEvent.KEYCODE_TAB,    0, 0, 110, 42, 26));
        buttons.add(new Btn("OK",    KeyEvent.KEYCODE_ENTER,  0, 0, 175, 42, 26));
        buttons.add(new Btn("Y",     KeyEvent.KEYCODE_Y,      0, 0, 240, 42, 26));
        buttons.add(new Btn("N",     KeyEvent.KEYCODE_N,      0, 0, 305, 42, 26));

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2 * density);
        text.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        for (Btn b : buttons) {
            b.cx = b.ax * w + b.ox * density;
            b.cy = b.ay * h + b.oy * density;
            b.rad = b.r * density;
        }
        padR = 88 * density;
        padCx = 40 * density + padR + 20 * density;
        padCy = h - padR - 24 * density;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int skip = -1;
        boolean cancel = false;
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            cancel = true;
        } else if (action == MotionEvent.ACTION_POINTER_UP) {
            skip = e.getActionIndex();
        }

        Set<Integer> want = new HashSet<Integer>();
        pressedButtons.clear();
        padUp = padDown = padLeft = padRight = false;
        knobActive = false;

        if (!cancel) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                if (i == skip) continue;
                float x = e.getX(i), y = e.getY(i);

                // cruz de movimiento
                float dx = x - padCx, dy = y - padCy;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist <= padR * 1.7f) {
                    float dead = padR * 0.28f;
                    if (dy < -dead) padUp = true;
                    if (dy > dead) padDown = true;
                    if (dx < -dead) padLeft = true;
                    if (dx > dead) padRight = true;
                    float k = Math.min(dist, padR) / (dist == 0 ? 1 : dist);
                    knobX = padCx + dx * k;
                    knobY = padCy + dy * k;
                    knobActive = true;
                    continue;
                }

                // botones
                for (Btn b : buttons) {
                    float bx = x - b.cx, by = y - b.cy;
                    if (Math.sqrt(bx * bx + by * by) <= b.rad * 1.25f) {
                        pressedButtons.add(b);
                        break;
                    }
                }
            }
        }

        if (padUp) want.add(KeyEvent.KEYCODE_DPAD_UP);
        if (padDown) want.add(KeyEvent.KEYCODE_DPAD_DOWN);
        if (padLeft) want.add(KeyEvent.KEYCODE_DPAD_LEFT);
        if (padRight) want.add(KeyEvent.KEYCODE_DPAD_RIGHT);
        for (Btn b : pressedButtons) want.add(b.key);

        syncKeys(want);
        invalidate();
        return true; // consumimos todo: asi SDL no convierte toques en clics de mouse (que dispararian)
    }

    private void syncKeys(Set<Integer> want) {
        for (Integer k : new ArrayList<Integer>(down)) {
            if (!want.contains(k)) {
                down.remove(k);
                SDLActivity.onNativeKeyUp(k);
            }
        }
        for (Integer k : want) {
            if (!down.contains(k)) {
                down.add(k);
                SDLActivity.onNativeKeyDown(k);
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        syncKeys(new HashSet<Integer>());
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        // cruz de movimiento
        fill.setColor(0x33FFFFFF);
        c.drawCircle(padCx, padCy, padR, fill);
        stroke.setColor(0x66FFFFFF);
        c.drawCircle(padCx, padCy, padR, stroke);
        text.setColor(0x99FFFFFF);
        text.setTextSize(22 * density);
        float o = padR * 0.68f;
        c.drawText("^", padCx, padCy - o + 8 * density, text);
        c.drawText("v", padCx, padCy + o + 4 * density, text);
        c.drawText("<", padCx - o, padCy + 8 * density, text);
        c.drawText(">", padCx + o, padCy + 8 * density, text);
        if (knobActive) {
            fill.setColor(0x66FFFFFF);
            c.drawCircle(knobX, knobY, padR * 0.32f, fill);
        }

        // botones
        for (Btn b : buttons) {
            boolean p = pressedButtons.contains(b);
            fill.setColor(p ? 0x77FFFFFF : 0x33FFFFFF);
            c.drawCircle(b.cx, b.cy, b.rad, fill);
            stroke.setColor(p ? 0xCCFFFFFF : 0x66FFFFFF);
            c.drawCircle(b.cx, b.cy, b.rad, stroke);
            text.setColor(0xCCFFFFFF);
            float size = b.rad * (b.label.length() > 3 ? 0.42f : 0.55f);
            text.setTextSize(size);
            c.drawText(b.label, b.cx, b.cy + size * 0.35f, text);
        }
    }
}
