# Doom para Android (source port)

Source port de **Doom** para Android basado en **Chocolate Doom 3.1.1** (fiel al original) sobre **SDL2 / SDL2_mixer**.

- Comportamiento identico al Doom original (sin mejoras de jugabilidad).
- Unica mejora: **pantalla completa inmersiva** (sin barras del sistema, usa la zona del notch, imagen estirada a toda la pantalla).
- Controles tactiles superpuestos, mando Bluetooth/teclado tambien funcionan.
- **No incluye ningun WAD.** Al abrir la app se elige el propio `doom.wad`, `doom2.wad` o `doom1.wad` (shareware).

## Estructura

```
app/jni/                 CMake nativo (SDL2 + SDL2_mixer + Chocolate Doom -> libmain.so)
app/src/main/java/       SDLActivity (SDL2), LauncherActivity (elegir WAD), DoomActivity, TouchControlsView
third_party/             Codigo fuente de SDL2 2.30.9, SDL2_mixer 2.8.0 y Chocolate Doom
.github/workflows/       Compilacion automatica del APK en GitHub Actions
```

## Compilar

### Opcion A: Android Studio
1. Abrir esta carpeta con Android Studio.
2. En *SDK Manager > SDK Tools* instalar **NDK (Side by side)** y **CMake 3.22.1**.
3. *Build > Build APK(s)*, o ejecutar directo en el telefono.

### Opcion B: linea de comandos
```
./gradlew assembleDebug
```
El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.
Requiere JDK 17 y el SDK de Android (platform 34, NDK 26, CMake 3.22.1).

### Opcion C: sin instalar nada
Subir la carpeta a un repositorio de GitHub: el workflow **Build APK** compila y deja el APK
como artefacto descargable (pestana *Actions*).

## Controles tactiles

| Zona | Control |
|------|---------|
| Izquierda | Cruz de movimiento (adelante / atras / girar, con diagonales) |
| Derecha | FUEGO (Ctrl) y USAR (Espacio) |
| Centro abajo | Strafe izquierda / derecha |
| Arriba derecha | Arma anterior / siguiente |
| Arriba izquierda | ESC (menu), MAPA (Tab), OK (Enter), Y / N para confirmar |

El boton *atras* de Android equivale a ESC.

## Notas

- La imagen se **estira para llenar toda la pantalla** (sin bandas negras). Es un cambio chico en `i_video.c` (variable `stretch_to_fill`, activa por defecto en Android; con `stretch_to_fill 0` en `chocolate-doom.cfg` vuelve la proporcion original 4:3).
- La configuracion inicial (pantalla completa, sin pantalla ENDOOM al salir, correr siempre) se escribe una sola vez en el almacenamiento interno de la app.
- Sin multijugador por red (SDL2_net desactivado).

## Licencias

- Chocolate Doom: GPL v2. SDL2 / SDL2_mixer: zlib. Este proyecto incluye el codigo fuente completo.
- Los WAD comerciales de Doom tienen copyright y no se incluyen ni se distribuyen.
